export class Quiz {

    constructor(
        public quizId :Number,
        public categoryName : string,
        public quizName : string
    ){}
}
