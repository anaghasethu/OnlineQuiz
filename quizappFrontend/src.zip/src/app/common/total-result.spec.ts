import { TotalResult } from './total-result';

describe('TotalResult', () => {
  it('should create an instance', () => {
    expect(new TotalResult()).toBeTruthy();
  });
});
