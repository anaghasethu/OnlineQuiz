export class TotalResult {

    constructor(public id : string,
        public res  : Number){}
}
