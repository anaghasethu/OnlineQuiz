export class User {

    constructor(
        public userID : string,
        public userName : string,
        public password : string,
        public role : string){}
}
