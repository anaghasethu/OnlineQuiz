export class Category {

    constructor(
        public category : string
    ){}
}
